<template>
  <div
    class="backGround h-100 row justify-content-center w-100 align-items-center"
  >
    <div class="col text-center">
      <img
        src="ghanari.png"
        alt="ghanari logo"
        class="rounded-circle shadow-lg"
        style="width: 200px"
      />
      <h2><div class="text-info mt-3">Welcome to Ghanari</div></h2>
    </div>
  </div>
</template>

<script></script>

<style lang="css" scoped>
.backGround {
  background-color: lavender;
}
</style>
